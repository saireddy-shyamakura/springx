package com.example.boostre;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoostreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoostreApplication.class, args);
	}

}
