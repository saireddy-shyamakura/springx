package com.example.boostre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoostreApplicationTests {

	@Test
	void contextLoads() {
	}

}
